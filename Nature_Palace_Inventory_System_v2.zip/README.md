# Nature Palace Inventory & Sales

A scalable Flask + SQLAlchemy inventory and sales management application for Nature Palace.

## Included
- Secure session login with hashed password
- Role-ready user model (`admin` / future roles)
- Dashboard with stock, products, categories, customers, sales and low-stock metrics
- Categories and products
- Serialized and quantity-based inventory
- Unique serial numbers with available/sold/removed state
- Stock movement audit trail
- Customers and purchase history
- Sales/invoices with automatic stock deduction
- Global search across products, SKU, serials, customers, phone and invoices
- Responsive Bootstrap UI
- SQLite by default; PostgreSQL supported through `DATABASE_URL`
- Upload support for category/product images

## Initial login
Username: `omar`
Password: `Omar@0807`

Change the password and `SECRET_KEY` before production use.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000`.

For PostgreSQL, set for example:
`DATABASE_URL=postgresql+psycopg://user:password@host/dbname`
and add an appropriate PostgreSQL driver to requirements.

## Production notes
Use HTTPS, a strong random `SECRET_KEY`, a production WSGI server (Gunicorn/Waitress), PostgreSQL for large deployments, scheduled backups, and reverse-proxy upload limits.

## Roles & Permissions (updated)

- `omar` is the protected main admin account.
- Admins can manage users, products, categories, inventory, customers, and sales.
- Staff users can view the operational dashboard, customers, sales, and create new sales / customers.
- Staff cannot access user management, product management, category management, or stock adjustments.
- Only admins can create, edit, deactivate, or reactivate user accounts.
- The main `omar` account cannot be deleted or demoted.

## New Sale safeguards

- The server always uses the product's current selling price; client-side price changes are ignored.
- Serialized items require an available serial number and are sold one unit at a time.
- The same serial cannot be added twice to a single sale.
- Sold/unavailable serials are rejected server-side.
- Non-serialized quantities must be positive and cannot exceed stock.
- Stock cannot become negative.
- Every completed sale creates stock movement records and marks serialized units as sold.
