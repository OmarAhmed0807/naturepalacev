function confirmDelete(msg){return confirm(msg||'Are you sure? This action cannot be undone.');}
